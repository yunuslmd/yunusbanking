package com.staragile.banking.banking;

import org.springframework.data.repository.CrudRepository;

public interface AccountDAORepository  extends CrudRepository<Account, String>{

}
